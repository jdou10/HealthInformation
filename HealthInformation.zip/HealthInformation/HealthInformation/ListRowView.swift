import SwiftUI

struct ListRowView: View {
    
    @EnvironmentObject var DoctorData: DoctorManager
    
    var singleDoctor: SingleDoctor
    
    //MARK: 注意这里与视频中不再相同；由于sort方法没有更改id，因此元素的id不再与其在数组ToDoList中的个数（index）相同；因此我们使用一个计算属性index来找到ToDoList中对应的singleToDo是在数组中的哪一个；
    var index: Int {
        self.DoctorData.DoctorList.firstIndex(where: { data in
            data.id == self.singleDoctor.id
        })!
    }
    
	var body: some View {
        VStack(alignment: .leading, spacing: 8) {            
            HStack {
                Text("Specialty：")
                Text(self.singleDoctor.specialty)
                    .foregroundColor(.gray)
            }
            HStack {
                Text("OfficeAddress：")
                Text(self.singleDoctor.officeAddress)
                    .foregroundColor(.gray)
            }
            HStack {
                Text("PhoneNumber：")
                Text(self.singleDoctor.phoneNumber)
                    .foregroundColor(.gray)
            }
        }
//        .background(Color.white)
//        .cornerRadius(10)
//        .shadow(radius: 10, x: 0, y: 10)
	}
    

}

struct ListRowView_Previews: PreviewProvider {
	static var previews: some View {
        ListRowView(singleDoctor: DoctorManager().DoctorList[0])
	}
}
