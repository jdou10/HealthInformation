import Foundation
import SwiftUI



struct ListView: View {
    
    @ObservedObject var DoctorData: DoctorManager = DoctorManager(data: initDoctorData())
    @State var showAddPage = false  // 添加界面
    @State private var searcDoctorName = "" // 搜索的医生姓名
    @State var showSearchPage = false // 搜索页面
    
    var body: some View {
        ZStack {
            NavigationView {
                VStack {
                    List{
                        ForEach(self.DoctorData.DoctorList) { item in
                            if !item.deleted {
                                ListRowView(singleDoctor: item)
                                    .environmentObject(self.DoctorData)
                                    .padding(.horizontal)
                                    .animation(.spring())
                                    .transition(.slide)
                            }
                        }
                        .onDelete(perform: ondelete) // 右滑删除
                    }
                }
                .navigationTitle("Doctors")
            }
            Spacer()
        }
        
        // 底部按钮
        VStack(spacing: 20) {
            VStack{
                Button(action: {
                    self.showAddPage = true;
                }, label: {
                    Text("Add")
                        .foregroundColor(.white)
                        .font(.headline)
                        .frame(height: 50)
                        .frame(maxWidth: .infinity)
                        .background(Color.accentColor)
                        .cornerRadius(10)
                })
                .fullScreenCover(isPresented: self.$showAddPage, content: {
                    AddView()
                        .environmentObject(self.DoctorData)
                })
                Spacer()
                    .frame(height:10)
                Button(action: {
                    self.showSearchPage = true
                }, label: {
                    Text("Search")
                        .foregroundColor(.white)
                        .font(.headline)
                        .frame(height: 50)
                        .frame(maxWidth: .infinity)
                        .background(Color.accentColor)
                        .cornerRadius(10)
                })
                .fullScreenCover(isPresented: self.$showSearchPage, content: {
                        SearchView()
                        .environmentObject(self.DoctorData)
                })
            }
            .padding()
            
        }
        
        
    }
    
    func ondelete(at offsets: IndexSet) {
        print(offsets)
//        self.DoctorData.DoctorList.remove(atOffsets: offsets)
        self.DoctorData.deleteIndexSet(id: offsets)
    }
}

struct ListView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            ListView()
        }
    }
}

//struct ListRowView: View {
//	var body: some View {
//		HStack {
//			Image(systemName: "checkmark.circle")
//			Text("Dr. Shledon")
//			Spacer()
//		}
//	}
//}
