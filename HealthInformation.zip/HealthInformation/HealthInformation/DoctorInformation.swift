import SwiftUI

@main
struct DoctorInformationApp: App {
    
    @ObservedObject var DoctorData: DoctorManager = DoctorManager(data: initDoctorData())
    @State var showEditingPage = false
    
    var body: some Scene {
        WindowGroup() {
            ListView()
                .frame(height:UIScreen.main.bounds.height)
        }
    }
}



var formatter = DateFormatter()
func initDoctorData() -> [SingleDoctor] {
    
    formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
    
    var output: [SingleDoctor] = []
    if let dataStored = UserDefaults.standard.object(forKey: "DoctorListData") as? Data {
        let data = try! decoder.decode([SingleDoctor].self, from: dataStored)
        for item in data {
            if !item.deleted {
                output.append(SingleDoctor(specialty: item.specialty, officeAddress: item.officeAddress, phoneNumber: item.phoneNumber, addDudate: item.addDudate, id: output.count))
            }
        }
    }
    return output
}
