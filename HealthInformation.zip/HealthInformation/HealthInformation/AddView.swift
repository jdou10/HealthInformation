import SwiftUI

struct AddView: View {

    @EnvironmentObject var DoctorData: DoctorManager
    
	@State var doctorSpecialty: String = ""
    @State var doctorOfficeAddress: String = ""
    @State var doctorPhoneNumber: String = ""
    @State var isShowAlert = false
    
    var id: Int? = nil
    
    @Environment(\.presentationMode) var presentation // 控制页面返回
    
	var body: some View {
        NavigationView {
            ScrollView {
                VStack {
                    // doctor specialty，doctor office address 和doctor phone number
                    TextField("doctor specialty", text: $doctorSpecialty)
                        .padding(.horizontal)
                        .frame(height: 55)
                        //.background(Color())
                        .cornerRadius(10)
                    Divider()
                    
                    TextField("doctor office address", text: $doctorOfficeAddress)
                        .padding(.horizontal)
                        .frame(height: 55)
                        //.background(Color())
                        .cornerRadius(10)
                    Divider()
                    
                    TextField("doctor phone number", text: $doctorPhoneNumber)
                        .padding(.horizontal)
                        .frame(height: 55)
                        //.background(Color())
                        .cornerRadius(10)
                }
                
                Spacer()
                    .frame(height:50)
                
                VStack(spacing: 10) {
                    Button(action: {
                        if self.id == nil {
                            if self.doctorSpecialty.isEmpty { // 表示姓名为空
                                self.isShowAlert = true
                            } else {
                                self.DoctorData.add(data: SingleDoctor(specialty: self.doctorSpecialty, officeAddress: self.doctorOfficeAddress, phoneNumber: self.doctorPhoneNumber, addDudate: Date(), deleted: false))
                                self.presentation.wrappedValue.dismiss()
                            }
                           
                        }
                        
                    }, label: {
                        Text("Save".lowercased())
                            .foregroundColor(.white)
                            .font(.headline)
                            .frame(height: 55)
                            .frame(maxWidth: .infinity)
                            .background(Color.accentColor)
                            .cornerRadius(10)
                    })
                    
                    Button(action: {
                        self.presentation.wrappedValue.dismiss()
                    }, label: {
                        Text("Cancel".lowercased())
                            .foregroundColor(.white)
                            .font(.headline)
                            .frame(height: 55)
                            .frame(maxWidth: .infinity)
                            .foregroundColor(Color.white)
                    })
                    .background(Color.black)
                    .opacity(0.55)
                    .cornerRadius(10)
                }
                .padding()
                .alert(isPresented: self.$isShowAlert) {
                   Alert(title: Text("Warning"), message: Text("Not allowed to be empty. Please enter the specialty infomation ."))
                }
                .navigationTitle("Add Doctors")
                
            }
        }
		
	}
}

struct AddView_Previews: PreviewProvider {
	static var previews: some View {
		NavigationView {
			AddView()
		}
	}
}
